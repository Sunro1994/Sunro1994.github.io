# Security Policy

## Supported Versions

| Version    | Supported |
| :--------- | :-------: |
| >= `7.0.0` |     ✓     |
| <= `6.0.0` |     ✗     |

## Reporting a Vulnerability

If you find a vulnerability, please report it to `cotes.chung@gmail.com`.
We will try our best to respond within a week. Thank you for your time!
